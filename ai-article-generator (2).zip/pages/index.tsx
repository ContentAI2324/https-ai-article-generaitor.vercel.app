import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>ContentAI - Daily AI Articles</title>
      </Head>
      <main style={{ padding: '2rem', fontFamily: 'Arial' }}>
        <h1>Welcome to ContentAI</h1>
        <p>AI-generated fresh content daily!</p>
      </main>
    </>
  );
}
